
import React, { useState, useMemo } from 'react';
import { Header } from './components/Header';
import { SearchForm } from './components/SearchForm';
import { ResultsContainer } from './components/ResultsContainer';
import { InfoModal } from './components/InfoModal';
import { useData } from './hooks/useData';
import type { SearchCriteria, FilterState, EquivalencyResult, NoArticulationResult, MajorProgram, CollegeSchool, UcCourse, CccCollege } from './types';

const App: React.FC = () => {
  const { data, loading, error } = useData();
  const [isInfoModalOpen, setInfoModalOpen] = useState(false);
  
  const [searchCriteria, setSearchCriteria] = useState<SearchCriteria | null>(null);
  const [equivalencies, setEquivalencies] = useState<EquivalencyResult[]>([]);
  const [noArticulations, setNoArticulations] = useState<NoArticulationResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);

  const [filters, setFilters] = useState<FilterState>({
    acceptanceTypes: [],
    regions: [],
    hideNoEquivalency: false,
  });
  
  const filteredEquivalencies = useMemo(() => {
    return equivalencies.filter(eq => {
      const acceptanceMatch = filters.acceptanceTypes.length === 0 || filters.acceptanceTypes.includes(eq.acceptanceType);
      const regionMatch = filters.regions.length === 0 || (eq.cccCollege.region && filters.regions.includes(eq.cccCollege.region));
      return acceptanceMatch && regionMatch;
    });
  }, [equivalencies, filters]);
  
  const filteredNoArticulations = useMemo(() => {
    if (filters.hideNoEquivalency) return [];
    return noArticulations.filter(na => {
        return filters.regions.length === 0 || (na.cccCollege.region && filters.regions.includes(na.cccCollege.region));
    });
  }, [noArticulations, filters]);


  const handleSearch = async (criteria: SearchCriteria) => {
    setSearchCriteria(criteria);
    setIsSearching(true);
    setSearchError(null);
    
    try {
      if (!data) {
        throw new Error("Application data is not loaded.");
      }

      // Explicitly typed Maps to correct type inference issues where map values were being treated as 'unknown'.
      const ucCourseMap = new Map<number, UcCourse>(data.ucCourses.map(c => [c.id, c]));
      const majorProgramMap = new Map<number, MajorProgram>(data.majorPrograms.map(m => [m.id, m]));
      const collegeSchoolMap = new Map<number, CollegeSchool>(data.collegeSchools.map(cs => [cs.id, cs]));
      const cccCollegeMap = new Map<number, CccCollege>(data.cccColleges.map(c => [c.id, c]));
      
      const allEquivs = Array.isArray(data.equivalencies) ? data.equivalencies : [];
      const allNoArts = Array.isArray(data.noArticulations) ? data.noArticulations : [];
      
      const academicYear = String(criteria.academicYear ?? "").trim();
      const ucCourseId = criteria.ucCourseId;

      const matchingEquivalencies: EquivalencyResult[] = allEquivs
        .filter(eq => eq && eq.ucCourseId === ucCourseId && String(eq.academicYear) === academicYear)
        .map(eq => {
            const ucCourse = ucCourseMap.get(eq.ucCourseId);
            const majorProgram = ucCourse ? majorProgramMap.get(ucCourse.majorProgramId) : undefined;
            const collegeSchool = majorProgram ? collegeSchoolMap.get(majorProgram.collegeSchoolId) : undefined;
            const cccCollege = cccCollegeMap.get(eq.cccCollegeId);

            return cccCollege && ucCourse && majorProgram && collegeSchool 
              ? { ...eq, cccCollege, ucCourse, majorProgram, collegeSchool } 
              : null;
        })
        .filter((eq): eq is EquivalencyResult => eq !== null);

      const articulatedCccIds = new Set(matchingEquivalencies.map(eq => eq.cccCollegeId));

      const matchingNoArticulations: NoArticulationResult[] = allNoArts
          .filter(na => na && na.ucCourseId === ucCourseId && String(na.academicYear) === academicYear && !articulatedCccIds.has(na.cccCollegeId))
          .map(na => {
              const cccCollege = cccCollegeMap.get(na.cccCollegeId);
              return cccCollege ? { ...na, cccCollege } : null;
          })
          .filter((na): na is NoArticulationResult => na !== null);


      setEquivalencies(matchingEquivalencies);
      setNoArticulations(matchingNoArticulations);
      
      const selectedMajor = data.majorPrograms.find(m => m.id === criteria.majorProgramId);
      const publicId = (selectedMajor as any)?.id ?? null;
      const mappedId = data.majorProgramIdByPublicId?.[publicId as string] ?? null;
      const activeMajorProgramId = mappedId ?? (selectedMajor as any)?.majorProgramId ?? criteria.majorProgramId;

      console.log('[Transfer Finder] search results built.', {
        academicYear,
        ucCourseId,
        'major publicId': publicId,
        activeMajorProgramId,
        counts: { eq: matchingEquivalencies.length, noEq: matchingNoArticulations.length },
      });

    } catch (e) {
      console.error("[Transfer Finder] search/build failed:", e);
      setSearchError(e instanceof Error ? e.message : String(e));
      setEquivalencies([]);
      setNoArticulations([]);
    } finally {
      setIsSearching(false);
    }
  };

  if (loading) {
    return <div className="flex items-center justify-center min-h-screen">Loading data...</div>;
  }

  if (error) {
    return <div className="flex items-center justify-center min-h-screen text-red-500">Error: {error}</div>;
  }

  return (
    <div className="min-h-screen bg-slate-100">
      <Header onInfoClick={() => setInfoModalOpen(true)} />
      <main className="container mx-auto p-4 md:p-6 lg:p-8">
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-xl font-bold text-slate-700 mb-4">Find Course Equivalencies</h2>
          {data && <SearchForm data={data} onSearch={handleSearch} />}
        </div>
        
        {searchCriteria && (
          <ResultsContainer
            isSearching={isSearching}
            searchError={searchError}
            equivalencies={filteredEquivalencies}
            noArticulations={filteredNoArticulations}
            filters={filters}
            onFilterChange={setFilters}
            searchCriteria={searchCriteria}
            data={data!}
          />
        )}
      </main>
      <InfoModal isOpen={isInfoModalOpen} onClose={() => setInfoModalOpen(false)} />
    </div>
  );
};

export default App;
