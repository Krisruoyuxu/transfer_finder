
import React from 'react';
import type { AppData, EquivalencyResult, FilterState, NoArticulationResult, SearchCriteria } from '../types';
import { ResultsTable } from './ResultsTable';
import { NoArticulationList } from './NoArticulationList';
import { Filters } from './Filters';
import { DownloadIcon } from './icons/DownloadIcon';

interface ResultsContainerProps {
  isSearching: boolean;
  searchError: string | null;
  equivalencies: EquivalencyResult[];
  noArticulations: NoArticulationResult[];
  filters: FilterState;
  onFilterChange: (filters: FilterState) => void;
  searchCriteria: SearchCriteria;
  data: AppData;
}

export const ResultsContainer: React.FC<ResultsContainerProps> = ({
  isSearching,
  searchError,
  equivalencies,
  noArticulations,
  filters,
  onFilterChange,
  searchCriteria,
  data,
}) => {
  if (isSearching) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="text-center p-8">Loading result details...</div>
      </div>
    );
  }

  if (searchError) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="text-center py-6 text-red-600">
          Unable to load results. Try a different selection or check console.
        </div>
      </div>
    );
  }

  const ucCampus = data.ucCampuses.find(c => c.id === searchCriteria.ucCampusId);
  const majorProgram = data.majorPrograms.find(mp => mp.id === searchCriteria.majorProgramId);
  const collegeSchool = majorProgram ? data.collegeSchools.find(cs => cs.id === majorProgram.collegeSchoolId) : undefined;
  const ucCourse = data.ucCourses.find(c => c.id === searchCriteria.ucCourseId);

  const exportToCSV = () => {
    const headers = [
      'UC Campus',
      'College/School',
      'Major/Program',
      'UC Course Code',
      'UC Course Title',
      'Academic Year',
      'CCC Name',
      'CCC Course Code',
      'CCC Course Title',
      'Acceptance Type',
      'Display Context',
      'Remarks',
      'Verification URL',
    ];
  
    const rows = equivalencies.map(eq => [
      ucCampus?.name,
      eq.collegeSchool.name,
      eq.majorProgram.name,
      eq.ucCourse.courseCode,
      eq.ucCourse.title,
      eq.academicYear,
      eq.cccCollege.name,
      eq.cccCourseCode,
      eq.cccCourseTitle,
      eq.acceptanceType,
      eq.displayContext,
      eq.remarks || '',
      eq.verifyUrl,
    ]);
  
    let csvContent = "data:text/csv;charset=utf-8," 
      + [headers.join(','), ...rows.map(row => row.map(field => `"${String(field).replace(/"/g, '""')}"`).join(','))].join("\n");
  
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `transfer-finder-export_${ucCourse?.courseCode}_${searchCriteria.academicYear}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  if (!ucCampus || !majorProgram || !ucCourse) {
    return (
        <div className="bg-white rounded-lg shadow-md p-6">
            <div className="text-center py-12">
                <h4 className="text-lg font-semibold text-slate-700">No Data Found</h4>
                <p className="text-slate-500">No articulation data is available for this course and academic year in our dataset.</p>
            </div>
        </div>
    );
  }
  
  const hasResults = equivalencies.length > 0 || noArticulations.length > 0;

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="border-b border-slate-200 pb-4 mb-4">
        <h3 className="text-xl font-bold text-slate-800">
          Results for: {ucCourse.courseCode} - {ucCourse.title}
        </h3>
        <div className="flex flex-wrap gap-x-4 gap-y-2 text-sm text-slate-500 mt-2">
            <span><strong>Campus:</strong> {ucCampus.name}</span>
            {collegeSchool && <span><strong>College:</strong> {collegeSchool.name}</span>}
            <span><strong>Major:</strong> {majorProgram.name}</span>
            <span><strong>Year:</strong> {searchCriteria.academicYear}</span>
        </div>
      </div>
      
      {hasResults ? (
        <>
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-4">
                <Filters filters={filters} onFilterChange={onFilterChange} cccData={data.cccColleges} />
                <button
                    onClick={exportToCSV}
                    disabled={equivalencies.length === 0}
                    className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-blue-600 bg-blue-50 border border-blue-200 rounded-md hover:bg-blue-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    <DownloadIcon />
                    Export CSV
                </button>
            </div>

            <div className="space-y-8">
                <ResultsTable equivalencies={equivalencies} />
                {!filters.hideNoEquivalency && <NoArticulationList noArticulations={noArticulations} />}
            </div>
        </>
      ) : (
        <div className="text-center py-12">
            <h4 className="text-lg font-semibold text-slate-700">No Data Found</h4>
            <p className="text-slate-500">No articulation data is available for this course and academic year in our dataset.</p>
        </div>
      )}
    </div>
  );
};
