
import React from 'react';

interface InfoModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InfoModal: React.FC<InfoModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center" onClick={onClose}>
      <div className="bg-white rounded-lg shadow-xl p-6 m-4 max-w-lg w-full" onClick={e => e.stopPropagation()}>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-slate-800">About Transfer Finder</h2>
          <button onClick={onClose} className="p-1 rounded-full text-slate-400 hover:bg-slate-200" aria-label="Close modal">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        <div className="space-y-4 text-slate-600">
          <p>This tool provides a "reverse lookup" for course equivalencies, helping students find which California Community Colleges (CCCs) offer courses that are articulated for a specific UC course.</p>
          <div>
            <h3 className="font-semibold text-slate-700">Key Considerations:</h3>
            <ul className="list-disc list-inside mt-2 space-y-1">
              <li><strong>Academic Year Matters:</strong> Articulation agreements are year-specific. An agreement from a previous year is not guaranteed to be valid for the current year. Always select the correct academic year for your planning.</li>
              <li><strong>By-Major vs. By-Department:</strong> A course's acceptance can differ depending on the context. 'By-major' agreements are specific to a particular degree program, while 'by-department' agreements are more general. Pay attention to the 'Context' column.</li>
              <li><strong>Always Verify on ASSIST:</strong> The "Verify" links lead to ASSIST.org, the official source for California's articulation information. This tool is a guide, but you <strong className="font-bold">must</strong> confirm all information on ASSIST.org with a counselor.</li>
               <li><strong>Data Source:</strong> The data in this demo is a static, pre-loaded snapshot and is for illustrative purposes only. It does not reflect live data from ASSIST.org.</li>
            </ul>
          </div>
        </div>
        <div className="mt-6 text-right">
            <button
                onClick={onClose}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
                Got it
            </button>
        </div>
      </div>
    </div>
  );
};
