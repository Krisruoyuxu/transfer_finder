
import React, { useMemo } from 'react';
import type { FilterState, AcceptanceType, CccCollege } from '../types';

interface FiltersProps {
  filters: FilterState;
  onFilterChange: (newFilters: FilterState) => void;
  cccData: CccCollege[];
}

const acceptanceTypes: AcceptanceType[] = ['exact', 'substitute', 'conditional'];

export const Filters: React.FC<FiltersProps> = ({ filters, onFilterChange, cccData }) => {
  const regions = useMemo(() => {
    const allRegions = new Set(cccData.map(c => c.region).filter(Boolean));
    return Array.from(allRegions).sort();
  }, [cccData]);

  const handleAcceptanceChange = (type: AcceptanceType) => {
    const newTypes = filters.acceptanceTypes.includes(type)
      ? filters.acceptanceTypes.filter(t => t !== type)
      : [...filters.acceptanceTypes, type];
    onFilterChange({ ...filters, acceptanceTypes: newTypes });
  };

  const handleRegionChange = (region: string) => {
    const newRegions = filters.regions.includes(region)
        ? filters.regions.filter(r => r !== region)
        : [...filters.regions, region];
    onFilterChange({ ...filters, regions: newRegions });
  };

  return (
    <div className="flex flex-col sm:flex-row flex-wrap gap-x-6 gap-y-4">
      <div>
        <span className="text-sm font-semibold text-slate-700 mr-3">Acceptance:</span>
        <div className="inline-flex rounded-md shadow-sm" role="group">
          {acceptanceTypes.map((type, index) => (
            <button
              key={type}
              onClick={() => handleAcceptanceChange(type)}
              className={`px-3 py-1 text-sm font-medium border border-slate-300
                ${filters.acceptanceTypes.includes(type) ? 'bg-blue-500 text-white' : 'bg-white text-slate-700 hover:bg-slate-50'}
                ${index === 0 ? 'rounded-l-lg' : ''}
                ${index === acceptanceTypes.length - 1 ? 'rounded-r-lg' : ''}`}
            >
              {type.charAt(0).toUpperCase() + type.slice(1)}
            </button>
          ))}
        </div>
      </div>
       <div className="flex items-center">
        <input
          type="checkbox"
          id="hideNoEquivalency"
          checked={filters.hideNoEquivalency}
          onChange={e => onFilterChange({ ...filters, hideNoEquivalency: e.target.checked })}
          className="h-4 w-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500"
        />
        <label htmlFor="hideNoEquivalency" className="ml-2 block text-sm text-slate-700">
          Hide 'No Course Articulated'
        </label>
      </div>
    </div>
  );
};
