
import React, { useState, useEffect, useMemo } from 'react';
import type { AppData, SearchCriteria } from '../types';

interface SearchFormProps {
  data: AppData;
  onSearch: (criteria: SearchCriteria) => void;
}

export const SearchForm: React.FC<SearchFormProps> = ({ data, onSearch }) => {
  const [year, setYear] = useState<string>('');
  const [campusId, setCampusId] = useState<string>('');
  const [collegeSchoolId, setCollegeSchoolId] = useState<string>('');
  const [majorProgramId, setMajorProgramId] = useState<string>('');
  const [courseId, setCourseId] = useState<string>('');

  const academicYears = useMemo(() => {
    const allYears = new Set([...data.equivalencies.map(e => e.academicYear), ...data.noArticulations.map(na => na.academicYear)]);
    return Array.from(allYears).sort().reverse();
  }, [data.equivalencies, data.noArticulations]);

  const collegeSchools = useMemo(() => {
    if (!campusId) return [];
    return data.collegeSchools
      .filter(cs => cs.ucCampusId === parseInt(campusId))
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [campusId, data.collegeSchools]);

  const majorPrograms = useMemo(() => {
    if (!campusId) return [];

    if (collegeSchoolId) {
      return data.majorPrograms
        .filter(mp => mp.collegeSchoolId === parseInt(collegeSchoolId))
        .sort((a, b) => a.name.localeCompare(b.name));
    }
    
    const campusCollegeIds = new Set(
      data.collegeSchools
        .filter(cs => cs.ucCampusId === parseInt(campusId))
        .map(cs => cs.id)
    );
    return data.majorPrograms
      .filter(mp => campusCollegeIds.has(mp.collegeSchoolId))
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [campusId, collegeSchoolId, data.majorPrograms, data.collegeSchools]);

  const courses = useMemo(() => {
    if (!majorProgramId) return [];

    const mappedId = data.majorProgramIdByPublicId?.[majorProgramId];
    
    let activeMajorProgramId: number | null = null;
    if (mappedId !== undefined) {
        activeMajorProgramId = mappedId;
    } else {
        const parsed = parseInt(majorProgramId, 10);
        if (!isNaN(parsed)) {
            activeMajorProgramId = parsed;
        }
    }
    
    if (activeMajorProgramId === null) {
        return [];
    }

    return data.ucCourses
      .filter(c => c.majorProgramId === activeMajorProgramId)
      .sort((a, b) => a.courseCode.localeCompare(b.courseCode));
  }, [majorProgramId, data.ucCourses, data.majorProgramIdByPublicId]);

  // Set default academic year
  useEffect(() => {
    if (academicYears.length > 0 && !year) {
      setYear(academicYears[0]);
    }
  }, [academicYears, year]);

  // Cascade Reset Logic
  useEffect(() => { setCampusId(''); }, [year]);
  useEffect(() => { setCollegeSchoolId(''); }, [campusId]);
  useEffect(() => { setMajorProgramId(''); }, [collegeSchoolId]);
  useEffect(() => { setCourseId(''); }, [majorProgramId]);


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (year && campusId && majorProgramId && courseId) {
      onSearch({
        academicYear: year,
        ucCampusId: parseInt(campusId),
        collegeSchoolId: collegeSchoolId ? parseInt(collegeSchoolId) : undefined,
        majorProgramId: parseInt(majorProgramId),
        ucCourseId: parseInt(courseId),
      });
    }
  };

  const isFormIncomplete = !year || !campusId || !majorProgramId || !courseId;

  return (
    <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4 items-end">
      <SelectField label="Academic Year" value={year} onChange={e => setYear(e.target.value)}>
        <option value="" disabled>Select year</option>
        {academicYears.map(y => <option key={y} value={y}>{y}</option>)}
      </SelectField>

      <SelectField label="UC Campus" value={campusId} onChange={e => setCampusId(e.target.value)} disabled={!year}>
        <option value="" disabled>Select campus</option>
        {data.ucCampuses.map(campus => <option key={campus.id} value={campus.id}>{campus.name}</option>)}
      </SelectField>

      <SelectField label="College / School" value={collegeSchoolId} onChange={e => setCollegeSchoolId(e.target.value)} disabled={!campusId}>
        <option value="">-- All Colleges --</option>
        {collegeSchools.map(cs => <option key={cs.id} value={cs.id}>{cs.name}</option>)}
      </SelectField>

      <SelectField label="Major / Program" value={majorProgramId} onChange={e => setMajorProgramId(e.target.value)} disabled={!campusId}>
        <option value="" disabled>Select major</option>
        {majorPrograms.map(mp => <option key={mp.id} value={mp.id}>{mp.name}</option>)}
      </SelectField>

      <SelectField label="UC Course" value={courseId} onChange={e => setCourseId(e.target.value)} disabled={!majorProgramId}>
        <option value="" disabled>Select course</option>
        {courses.map(course => <option key={course.id} value={course.id}>{course.courseCode} - {course.title}</option>)}
      </SelectField>

      <button
        type="submit"
        disabled={isFormIncomplete}
        className="w-full px-4 py-2 text-white font-semibold bg-blue-600 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-slate-400 disabled:cursor-not-allowed"
      >
        Search
      </button>
    </form>
  );
};

interface SelectFieldProps {
    label: string;
    value: string;
    onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
    children: React.ReactNode;
    disabled?: boolean;
}

const SelectField: React.FC<SelectFieldProps> = ({ label, value, onChange, children, disabled = false }) => (
    <div>
        <label className="block text-sm font-medium text-slate-700 mb-1">{label}</label>
        <select value={value} onChange={onChange} disabled={disabled} className="block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm disabled:bg-slate-50 disabled:text-slate-500 disabled:border-slate-200 disabled:shadow-none">
            {children}
        </select>
    </div>
);