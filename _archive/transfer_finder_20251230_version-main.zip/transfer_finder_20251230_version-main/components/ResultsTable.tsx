
import React from 'react';
import type { EquivalencyResult, AcceptanceType, DisplayContext } from '../types';
import { ExternalLinkIcon } from './icons/ExternalLinkIcon';

interface ResultsTableProps {
  equivalencies: EquivalencyResult[];
}

const AcceptanceBadge: React.FC<{ type: AcceptanceType }> = ({ type }) => {
  const baseClasses = 'px-2 py-0.5 text-xs font-semibold rounded-full';
  const typeClasses = {
    exact: 'bg-green-100 text-green-800',
    substitute: 'bg-yellow-100 text-yellow-800',
    conditional: 'bg-orange-100 text-orange-800',
  };
  return <span className={`${baseClasses} ${typeClasses[type]}`}>{type}</span>;
};

const ContextBadge: React.FC<{ context: DisplayContext }> = ({ context }) => {
    const baseClasses = 'px-2 py-0.5 text-xs font-medium rounded-full';
    const typeClasses = {
      'by-major': 'bg-indigo-100 text-indigo-800',
      'by-department': 'bg-sky-100 text-sky-800',
    };
    const text = context.replace('-', ' ');
    return <span className={`${baseClasses} ${typeClasses[context]}`}>{text}</span>;
};

export const ResultsTable: React.FC<ResultsTableProps> = ({ equivalencies }) => {
  if (equivalencies.length === 0) {
    return (
        <div>
            <h4 className="text-lg font-semibold text-slate-700 mb-2">Articulated Courses</h4>
            <div className="bg-slate-50 border border-dashed border-slate-300 rounded-lg p-8 text-center">
                <p className="text-slate-500">No matching articulated courses found with the current filters.</p>
            </div>
        </div>
    );
  }

  return (
    <div>
      <h4 className="text-lg font-semibold text-slate-700 mb-2">Articulated Courses ({equivalencies.length})</h4>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-slate-200">
          <thead className="bg-slate-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Community College</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">CCC Course</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Acceptance</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Context</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Verify</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-slate-200">
            {equivalencies.map(eq => (
              <tr key={eq.id} className="hover:bg-slate-50">
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900">{eq.cccCollege.name}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">
                    <div>{eq.cccCourseCode}</div>
                    <div className="text-xs text-slate-500">{eq.cccCourseTitle}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                    <AcceptanceBadge type={eq.acceptanceType} />
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                    <ContextBadge context={eq.displayContext} />
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <a href={eq.verifyUrl} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-800 inline-flex items-center gap-1">
                    ASSIST.org <ExternalLinkIcon />
                  </a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
