
import React from 'react';
import type { NoArticulationResult } from '../types';

interface NoArticulationListProps {
  noArticulations: NoArticulationResult[];
}

export const NoArticulationList: React.FC<NoArticulationListProps> = ({ noArticulations }) => {
  if (noArticulations.length === 0) {
    return null; // Don't render anything if the list is empty
  }

  return (
    <div>
      <h4 className="text-lg font-semibold text-slate-700 mb-2">No Course Articulated ({noArticulations.length})</h4>
      <p className="text-sm text-slate-500 mb-3">The following colleges have been confirmed to have no equivalent course for this academic year.</p>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
        {noArticulations.map(na => (
          <div key={na.id} className="bg-slate-100 p-2 rounded-md text-sm text-slate-700">
            {na.cccCollege.name}
          </div>
        ))}
      </div>
    </div>
  );
};
