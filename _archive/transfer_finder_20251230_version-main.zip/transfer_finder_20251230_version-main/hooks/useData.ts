
import { useState, useEffect } from 'react';
import type { AppData } from '../types';

export const useData = () => {
  const [data, setData] = useState<AppData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const [
          ucCampusesRes,
          collegeSchoolsRes,
          majorProgramsRes,
          ucCoursesRes,
          cccCollegesRes,
          equivalenciesRes,
          noArticulationsRes,
          ucCourseMajorMapRes,
        ] = await Promise.all([
          fetch('/data/uc-campuses.json'),
          fetch('/data/uc-colleges-schools.json'),
          fetch('/data/uc-majors-programs.json'),
          fetch('/data/uc-courses.json'),
          fetch('/data/ccc-colleges.json'),
          fetch('/data/equivalencies.json'),
          fetch('/data/no-articulations.json'),
          fetch('/data/uc-course-major-map.json'),
        ]);

        const allOk = [
            ucCampusesRes, collegeSchoolsRes, majorProgramsRes, 
            ucCoursesRes, cccCollegesRes, equivalenciesRes, noArticulationsRes
        ].every(res => res.ok);

        if (!allOk) {
            throw new Error('Failed to fetch one or more seed data files.');
        }
        
        const majorProgramIdByPublicId = ucCourseMajorMapRes.ok ? await ucCourseMajorMapRes.json() : {};

        const appData: AppData = {
          ucCampuses: await ucCampusesRes.json(),
          collegeSchools: await collegeSchoolsRes.json(),
          majorPrograms: await majorProgramsRes.json(),
          ucCourses: await ucCoursesRes.json(),
          cccColleges: await cccCollegesRes.json(),
          equivalencies: await equivalenciesRes.json(),
          noArticulations: await noArticulationsRes.json(),
          majorProgramIdByPublicId,
        };

        setData(appData);
        setError(null);
      } catch (err) {
        if (err instanceof Error) {
            setError(err.message);
        } else {
            setError('An unknown error occurred');
        }
        setData(null);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  return { data, loading, error };
};