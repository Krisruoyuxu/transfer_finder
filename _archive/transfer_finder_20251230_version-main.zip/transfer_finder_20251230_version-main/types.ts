
export interface UcCampus {
  id: number;
  name: string;
  code: string;
}

export interface CollegeSchool {
  id: number;
  ucCampusId: number;
  name: string;
}

export interface MajorProgram {
  id: number;
  collegeSchoolId: number;
  name: string;
}

export interface UcCourse {
  id: number;
  majorProgramId: number;
  courseCode: string;
  title: string;
  notes?: string;
}

export interface CccCollege {
  id: number;
  name: string;
  district: string;
  region: string;
  websiteUrl: string;
}

export type AcceptanceType = "exact" | "substitute" | "conditional";
export type DisplayContext = "by-major" | "by-department";

export interface Equivalency {
  id: number;
  ucCourseId: number;
  academicYear: string;
  cccCollegeId: number;
  cccCourseCode: string;
  cccCourseTitle: string;
  acceptanceType: AcceptanceType;
  displayContext: DisplayContext;
  remarks?: string;
  verifyUrl: string;
}

export interface NoArticulation {
  id: number;
  ucCourseId: number;
  academicYear: string;
  cccCollegeId: number;
  reason?: string;
}

export interface AppData {
  ucCampuses: UcCampus[];
  collegeSchools: CollegeSchool[];
  majorPrograms: MajorProgram[];
  ucCourses: UcCourse[];
  cccColleges: CccCollege[];
  equivalencies: Equivalency[];
  noArticulations: NoArticulation[];
  majorProgramIdByPublicId?: Record<string, number>;
}

export interface SearchCriteria {
  academicYear: string;
  ucCampusId: number;
  collegeSchoolId?: number;
  majorProgramId: number;
  ucCourseId: number;
}

export interface FilterState {
  acceptanceTypes: AcceptanceType[];
  regions: string[];
  hideNoEquivalency: boolean;
}

// Enriched types for display
export interface EquivalencyResult extends Equivalency {
  cccCollege: CccCollege;
  ucCourse: UcCourse;
  majorProgram: MajorProgram;
  collegeSchool: CollegeSchool;
}

export interface NoArticulationResult extends NoArticulation {
  cccCollege: CccCollege;
}